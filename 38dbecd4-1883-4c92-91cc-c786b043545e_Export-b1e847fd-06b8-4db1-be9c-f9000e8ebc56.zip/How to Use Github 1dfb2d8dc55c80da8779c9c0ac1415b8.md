# How to Use Github

# 1. Install git

Pass, do it yourself 😊

# 2. Clone the Github repository

## 2.1 Visit the repository website

Please visit https://github.com/JIJI5647/9120_assignment2/

## 2.2 Clone the repository

Get the URL here

![image.png](image.png)

Using this to clone the code.

```bash
git clone https://github.com/JIJI5647/9120_assignment2.git
```

You can see the document in your workplace.

![image.png](image%201.png)

Then, get into your workplace

```bash
cd 9120_assignment2
```

Switch to your branch

```bash
git checkout zmj
```

![image.png](image%202.png)

`Note` : If you using VSCode, you can switch or create the branch by doing that

![image.png](image%203.png)

![image.png](image%204.png)

# 3. Editing & commit & sync the change

Editing something

![image.png](image%205.png)

Click here

![image.png](image%206.png)

You can commit it and sync change to github.

![image.png](image%207.png)

You can see the change on website

![image.png](image%208.png)

# 4. Merging the code to main branch

Clicking here 

![image.png](image%209.png)

Clicking here 

![image.png](image%2010.png)

Choosing your branch

![image.png](image%2011.png)

Clicking here

![image.png](image%2012.png)

Adding comment and submitting 

![image.png](image%2013.png)

Then I will deal with the request.